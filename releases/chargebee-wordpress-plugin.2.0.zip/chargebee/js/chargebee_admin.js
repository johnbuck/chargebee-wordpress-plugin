jQuery(document).ready(function() {
  jQuery('#show-credentials').click(function(){
     jQuery('#webhook-credentials').attr("style", "display: inline");
  })
});
