<?php

class ChargeBee_SubscriptionCoupon extends ChargeBee_Model
{
  protected $allowed = array('coupon_id', 'apply_till', 'applied_count', 'coupon_code');

}

?>