<?php
class ChargeBee_Content extends ChargeBee_Result
{
	
}
?>