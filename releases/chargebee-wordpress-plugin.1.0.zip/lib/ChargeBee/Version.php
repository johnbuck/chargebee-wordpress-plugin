<?php

final class ChargeBee_Version
{
	  const VERSION = '1.3.6';
}

?>
