<?php

class ChargeBee_InvoiceTax extends ChargeBee_Model
{
  protected $allowed = array('amount', 'description');

}

?>