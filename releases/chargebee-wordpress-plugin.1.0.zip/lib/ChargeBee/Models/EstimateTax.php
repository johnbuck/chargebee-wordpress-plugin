<?php

class ChargeBee_EstimateTax extends ChargeBee_Model
{
  protected $allowed = array('amount', 'description');

}

?>