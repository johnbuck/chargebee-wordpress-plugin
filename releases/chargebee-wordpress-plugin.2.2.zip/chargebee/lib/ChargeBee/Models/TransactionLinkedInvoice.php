<?php

class ChargeBee_TransactionLinkedInvoice extends ChargeBee_Model
{
  protected $allowed = array('invoice_id', 'applied_amount', 'invoice_date', 'invoice_amount');

}

?>