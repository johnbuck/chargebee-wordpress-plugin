<?php

class ChargeBee_Download extends ChargeBee_Model
{

  protected $allowed = array('downloadUrl', 'validTill'
);



  # OPERATIONS
  #-----------

 }

?>