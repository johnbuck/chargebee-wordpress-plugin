<?php

class ChargeBee_TransactionLinkedRefund extends ChargeBee_Model
{
  protected $allowed = array('txn_id', 'txn_status', 'txn_date', 'txn_amount');

}

?>