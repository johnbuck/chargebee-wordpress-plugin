<?php

class ChargeBee_CustomerPaymentMethod extends ChargeBee_Model
{
  protected $allowed = array('type', 'gateway', 'status', 'reference_id');

}

?>