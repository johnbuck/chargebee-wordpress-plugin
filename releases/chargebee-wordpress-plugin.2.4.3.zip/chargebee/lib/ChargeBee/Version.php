<?php

final class ChargeBee_Version
{
	  const VERSION = '1.6.7';
}

?>
